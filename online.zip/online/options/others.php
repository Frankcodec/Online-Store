<?php 
?>
<style type="text/css">
	#others{
		border-bottom: 4px solid #fff;
	}
	#foods{
		border-bottom: none;
	}
</style>