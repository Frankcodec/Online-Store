<?php 
?>
<style type="text/css">
	#books{
		border-bottom: 4px solid #fff;
	}
	#foods{
		border-bottom: none;
	}
</style>