<?php 
$server = "localhost";
	$user = "root";
	$password = "";
	$db = "surge";
	$conn = new mysqli($server,$user,$password,$db);

		
?>